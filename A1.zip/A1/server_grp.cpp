#include <iostream>
#include <fstream>
#include<sstream>
#include <unordered_map>
#include<map>
#include<thread>
#include<mutex>
#include <cstring>
#include<vector>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <bits/stdc++.h>

#define PORT 12345
#define BUFFER_SIZE 1024
using namespace std;

//Shared resources
map<string,string>cred;
map<string,int>active;
mutex active_lock;
map<int,string>active_inv;
mutex active_inv_lock;
map<string,vector<int>>groups;
mutex groups_lock;
map<int,vector<string>>grp_ind;
mutex grp_ind_lock;

//Function to load credentials
int load_cred(string fname){
    cred.clear();
    string username, password,line;
    fstream file (fname,ios::in);

    if(file.is_open()){
        while(getline(file, line)){
            if(line[line.length()-1]==13) line.pop_back();
            stringstream str(line);
            getline(str, username, ':');
            getline(str, password, ':');
            cred[username]=password;
        }
        if(cred.empty()){
            cout<<"It is an empty file\n";
            return 0;
        }
        return 1;
    }
    else cout<<"Could not open the file\n";
    return 0;
}

//Function to broadcast message
int broadcast(string message, int client_socket){
    active_lock.lock();
    for(auto it:active){
        if(it.second!=client_socket){
            if(!(send(it.second, message.c_str(), message.size(), 0))){
                active_lock.unlock();
                return 0;
            }
        }
    }
    active_lock.unlock();
    return 1;
}

//Helper function to send the group message
int send_grp_msg(int client_socket, string message, string grpname){
    groups_lock.lock();
    for(auto it:groups[grpname]){
        if(it!=client_socket){
            if(!(send(it, message.c_str(), message.size(), 0))){
                message = "There was an error sending the message";
                send(client_socket, message.c_str(), message.size(), 0);
                groups_lock.unlock();
                return 0;
            }
        }
    }
    groups_lock.unlock();
    return 1;
}

//Function to send the group message with error handling
int grp_msg(int client_socket, string message, string grpname){
    //Check if group exists
    groups_lock.lock();
    if(groups.find(grpname)==groups.end()){
        message = "This group does not exist";
        send(client_socket, message.c_str(), message.size(),0);
        groups_lock.unlock();
        return 0;
    }

    //Check if client belongs to the group
    if(find(groups[grpname].begin(),groups[grpname].end(),client_socket)==groups[grpname].end()){
        message = "You are not a part of this group";
        send(client_socket, message.c_str(), message.size(),0);
        groups_lock.unlock();
        return 0;
    }

    groups_lock.unlock();
    active_inv_lock.lock();
    message="["+grpname+"] "+active_inv[client_socket]+": "+message;
    active_inv_lock.unlock();
    if(send_grp_msg(client_socket,message,grpname)==1){
        message = "Your group message has been sent";
        send(client_socket, message.c_str(), message.size(), 0);
    }
    return 1;
}

//Function to handle a client leaving
void leave(int client_socket){
    active_inv_lock.lock();
    string username=active_inv[client_socket];
    active_inv_lock.unlock();
    grp_ind_lock.lock();
    groups_lock.lock();

    //Leave all the groups that the client was a part of
    for(auto it: grp_ind[client_socket]){
        groups[it].erase(find(groups[it].begin(),groups[it].end(),client_socket));
    }
    grp_ind_lock.unlock();
    groups_lock.unlock();
    active_lock.lock();
    active.erase(username);
    active_lock.unlock();
    active_inv_lock.lock();
    active_inv.erase(client_socket);
    active_inv_lock.unlock();
    cout<<username+" has exited"<<endl;
    string message= username+" has exited the server";

    //Send a message to all active clients
    broadcast(message,client_socket);
    close(client_socket);
}

//Function to send private messages
int private_msg(int client_socket, string message, string recipient){
    //Check if recipient is different
    active_inv_lock.lock();
    if(recipient==active_inv[client_socket]){
        message="Sender and Recipient can't be same";
        send(client_socket, message.c_str(), message.size(), 0);
        active_inv_lock.unlock();
        return 0;
    }
    active_inv_lock.unlock();

    if(message.empty()){
        message="The message does not follow the standards";
        send(client_socket, message.c_str(), message.size(), 0);
        return 0;
    }

    active_lock.lock();
    //Check if recipient is active
    if(active.find(recipient)==active.end()){
        message="Not a valid active recipient!";
        send(client_socket, message.c_str(), message.size(), 0);
        active_lock.unlock();
        return 0;
    }
    active_lock.unlock();

    active_inv_lock.lock();
    message = "private_msg ["+active_inv[client_socket]+"]: "+message;
    active_inv_lock.unlock();
    active_lock.lock();
    if(send(active[recipient], message.c_str(), message.size(), 0)){
        message = "Your message has been sent";
        send(client_socket, message.c_str(), message.size(), 0);
    }else{
        message = "There was an error in sending your message";
        send(client_socket, message.c_str(), message.size(), 0);
    }
    active_lock.unlock();
    active_inv_lock.unlock();
    return 1;
}

//Function to join a group
int join_grp(int client_socket, string grp_name){
    int flag=0;
    groups_lock.lock();
    grp_ind_lock.lock();
    string message ="";
    if(groups.find(grp_name)!=groups.end()){
        if (find(groups[grp_name].begin(), groups[grp_name].end(), client_socket) == groups[grp_name].end()) {
            groups[grp_name].push_back(client_socket);
            grp_ind[client_socket].push_back(grp_name);
            message = "You have been added to the group.";
            send(client_socket, message.c_str(), message.size(), 0);
            flag=1;
        }
        else{
            message = "You have already joined the group " + grp_name;
            send(client_socket, message.c_str(), message.size(), 0);
            return 0;
        }
    }
    else{
        message = "This group does not exist";
        send(client_socket, message.c_str(), message.size(),0);
        return 0;
    }
    groups_lock.unlock();
    grp_ind_lock.unlock();

    if(flag==1){
        active_inv_lock.lock();
        message=active_inv[client_socket]+" has joined your group ["+grp_name+"]";
        active_inv_lock.unlock();
        //Notify all group members that a member has joined
        send_grp_msg(client_socket,message,grp_name);
    }
    return 1;
}

//Function to leave a group
int leave_grp(int client_socket, string grp_name){
    int flag=0;
    string message="";
    groups_lock.lock();
    grp_ind_lock.lock();
    if(groups.find(grp_name)!=groups.end()){
        if (find(groups[grp_name].begin(), groups[grp_name].end(), client_socket) != groups[grp_name].end()) {
            groups[grp_name].erase(find(groups[grp_name].begin(),groups[grp_name].end(),client_socket));
            grp_ind[client_socket].erase(find(grp_ind[client_socket].begin(),grp_ind[client_socket].end(),grp_name));
            message = "You have successfully left the group ["+ grp_name+"]";
            send(client_socket, message.c_str(), message.size(), 0);
            flag=1;
        }
        else{
            message = "You are not a part of the group [" + grp_name+']';
            send(client_socket, message.c_str(), message.size(), 0);
            return 0;
        }
    }
    else{
        message = "This group does not exist";
        send(client_socket, message.c_str(), message.size(),0);
        return 0;
    }
    groups_lock.unlock();
    grp_ind_lock.unlock();

    if(flag==1){
        active_inv_lock.lock();
        message=active_inv[client_socket]+" has exited your group ["+grp_name+"]";
        active_inv_lock.unlock();
        //Notify everyone in the group that the member has left 
        send_grp_msg(client_socket, message,grp_name);
    }
    return 1;
}

//Function to create a group
int create_grp(int client_socket, string grp_name){
    //checking if group already exists
    groups_lock.lock();
    string message ="";
    if(groups.find(grp_name)!=groups.end()){
        message = "This group already exists";
        send(client_socket, message.c_str(), message.size(),0);
        groups_lock.unlock();
        return 0;
    }

    //Updating the resources
    grp_ind_lock.lock();
    groups[grp_name].push_back(client_socket);
    grp_ind[client_socket].push_back(grp_name);
    message = "["+ grp_name + "] group has been created.";
    send(client_socket, message.c_str(), message.size(),0);
    grp_ind_lock.unlock();
    groups_lock.unlock();
    return 1;
}

//Function to process the commands
int process_command(int client_socket, const string& command) {
    string cmd="", msg="";
    int flag;

    //Splitting the input to command and message
    size_t spacePos = command.find(' '); 
    if (spacePos != string::npos) {
        cmd = command.substr(0, spacePos); 
        msg=command.substr(spacePos+1, command.length());
    
    } else {
        cmd = command; 
    }
    string recipient, message;
    if(cmd.empty()||(msg.empty() && (cmd!="/exit"||cmd!="/help"))){
        message="The message does not follow the standards";
        send(client_socket, message.c_str(), message.size(), 0);
        return 0;
    }

    if (cmd == "/msg") {
        size_t spacePos = msg.find(' '); 
        if (spacePos != string::npos) {
            recipient = msg.substr(0, spacePos); 
            message = msg.substr(spacePos+1, command.length());
        }
        else{
            message="The message does not follow the standards";
            send(client_socket, message.c_str(), message.size(), 0);
            return 0;
        }
        if(!private_msg(client_socket, message, recipient)) return 0;
    }
    else if (cmd == "/broadcast") {

        message= "Broadcast ["+active_inv[client_socket]+"]: "+msg;
        flag=broadcast(message, client_socket);
        if(flag==1){
            message = "Your message has been sent";
            send(client_socket, message.c_str(), message.size(), 0);
        }
        else{
            message = "There was an error in sending the message";
            send(client_socket, message.c_str(), message.size(), 0);
        }
    }
    else if (cmd == "/group_msg") {
        string grpname = "";
        size_t spacePos = msg.find(' '); 
        if (spacePos != string::npos) {
            grpname = msg.substr(0, spacePos); 
            message = msg.substr(spacePos+1, command.length());
        }
        else{
            message="The message does not follow the standards";
            send(client_socket, message.c_str(), message.size(), 0);
            return 0;
        }
        if(message.empty()||grpname.empty()){
            message="The message does not follow the standards";
            send(client_socket, message.c_str(), message.size(), 0);
            return 0;
        }
        
        if(!grp_msg(client_socket, message, grpname)) return 0;
    }
    else if (cmd == "/create_group") {
        if(!create_grp(client_socket, msg)) return 0;
    }
    else if (cmd == "/join_group") {
        if(!join_grp(client_socket, msg)) return 0;
    }
    else if (cmd == "/leave_group") {
        if(!leave_grp(client_socket, msg)) return 0;
    }
    else if (cmd == "/help") {
        string help_message = 
            "Available commands:\n"
            "/msg <username> <message> - Send private message\n"
            "/broadcast <message> - Send message to all the active users\n"
            "/group_msg <group_name> <message> - Send message to group\n"
            "/create_group <group_name> - Create a new group\n"
            "/join_group <group_name> - Join a group\n"
            "/leave_group <group_name> - Leave a group\n"
            "/help - Show this help message";

        send(client_socket, help_message.c_str(), help_message.length(), 0);
    }
    else if (cmd== "/exit"){
        leave(client_socket);
        return 1;
    }
    else{
        message="The message does not follow the standards";
        send(client_socket, message.c_str(), message.size(), 0);
    }
    return 0;
}

//Function to handle a client connection
void handle_client(int client_socket) {
    char buffer[BUFFER_SIZE];
    memset(buffer, 0, BUFFER_SIZE);
    
    // Request username
    string message = "Enter username: ";
    send(client_socket, message.c_str(), message.size(), 0);
    recv(client_socket, buffer, BUFFER_SIZE, 0);
    string username(buffer);
    
    // Request password
    memset(buffer, 0, BUFFER_SIZE);
    message = "Enter password: ";
    send(client_socket, message.c_str(), message.size(), 0);
    recv(client_socket, buffer, BUFFER_SIZE, 0);
    string password(buffer);
    
    // Authentication
    int flag=0;
    active_lock.lock();
    active_inv_lock.lock();
    if (cred.find(username) != cred.end() && cred.at(username) == password) {
        if(active.find(username)!=active.end()){
            message= "You are already logged in";
        }
        else{
            message = "Welcome to the chat server";
            active[username] = client_socket;
            active_inv[client_socket]=username;
            flag=1;
            cout<<username<<" joined the server\n";
        }
    } 
    else {
        message = "Authentication failed";
    }
    active_lock.unlock();
    active_inv_lock.unlock();
    send(client_socket, message.c_str(), message.size(), 0);
    if(flag==1){
        //Send a message to all active users
        message=username+ " has joined the server";
        broadcast(message,client_socket);
    }
    if(flag==0){
        close(client_socket);
        return;
    }
    while (true) {
        memset(buffer, 0, BUFFER_SIZE);
        int bytes_received = recv(client_socket, buffer, BUFFER_SIZE, 0);

        //If the client exits
        if (bytes_received <= 0) {
            leave(client_socket);
            return;
        }
        string message(buffer);
        message = message.substr(0, message.find('\n'));

        //Exit the loop if /exit was the command
        if(process_command(client_socket, message)==1) return;
    }
    close(client_socket);
    return;
}

int main(){
    int flag;
    flag=load_cred("users.txt");
    if(flag==0) return 0;
    int server_socket, client_socket;
    sockaddr_in server_address{}, client_address{};
    socklen_t client_len = sizeof(client_address);
    
    // Create socket
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        cerr << "Error creating socket." << endl;
        return 1;
    }

    //set options
    int opt = 1;
    if (setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt))) {
        cerr << "Error setting socket options" << endl;
        return 0;
    }
    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = INADDR_ANY;
    server_address.sin_port = htons(PORT);
    
    if (bind(server_socket, (struct sockaddr*)&server_address, sizeof(server_address)) < 0) {
        cerr << "Binding failed." << endl;
        return 1;
    }
    
    //Listen
    listen(server_socket, 50);
    cout << "Server listening on port " << PORT << endl;
    
    while (true) {
        client_socket = accept(server_socket, (struct sockaddr*)&client_address, &client_len);
        if (client_socket < 0) {
            cerr << "Error accepting connection" << endl;
            continue;
        }
        // Create a thread for the client and allow it to execute independently
        thread(handle_client,client_socket).detach();
    }
    close(server_socket);
    return 0;
}